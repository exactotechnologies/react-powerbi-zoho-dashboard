
# React Power BI Zoho Dashboard

Dashboard combining Zoho CRM data and embedded Power BI report.

## Install
npm install

## Run
npm start

## Features
- Zoho CRM leads fetch
- Power BI embed
- Unified analytics dashboard
