import axios from "axios";

const ACCESS_TOKEN = "YOUR_ZOHO_ACCESS_TOKEN";

export async function fetchZohoLeads() {
  const res = await axios.get(
    "https://www.zohoapis.com/crm/v2/Leads",
    {
      headers: { Authorization: "Zoho-oauthtoken " + ACCESS_TOKEN }
    }
  );
  return res.data.data || [];
}
