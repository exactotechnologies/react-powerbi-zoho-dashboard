import React, { useEffect, useState } from "react";
import { fetchZohoLeads } from "./zohoService";
import BIEmbed from "./PowerBIEmbed";

export default function Dashboard() {
  const [leads, setLeads] = useState([]);

  useEffect(() => {
    fetchZohoLeads().then(setLeads);
  }, []);

  return (
    <div>
      <h2>Zoho Leads</h2>

      <ul>
        {leads.map(l => (
          <li key={l.id}>
            {l.Full_Name || l.Last_Name} — {l.Email}
          </li>
        ))}
      </ul>

      <h2>Power BI Report</h2>
      <BIEmbed />
    </div>
  );
}
