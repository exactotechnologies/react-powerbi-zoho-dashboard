import React from "react";
import { PowerBIEmbed } from "powerbi-client-react";
import { models } from "powerbi-client";

export default function BIEmbed() {
  return (
    <PowerBIEmbed
      embedConfig={{
        type: "report",
        id: "POWERBI_REPORT_ID",
        embedUrl: "POWERBI_EMBED_URL",
        accessToken: "POWERBI_EMBED_TOKEN",
        tokenType: models.TokenType.Embed
      }}
      cssClassName="powerbi-frame"
      style={{ height: "500px" }}
    />
  );
}
